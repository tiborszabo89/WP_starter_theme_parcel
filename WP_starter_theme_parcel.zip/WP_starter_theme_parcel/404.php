<?php get_header(); ?>

<div class="container mt-5">
	<div class="row">
		<div class="col-12">
			<h2 class="text-center">Error 404 - Page Not Found</h2>
		</div>
	</div>
</div>

<?php get_footer(); ?>